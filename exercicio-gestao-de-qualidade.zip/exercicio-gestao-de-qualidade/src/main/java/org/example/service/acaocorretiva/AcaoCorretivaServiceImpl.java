package org.example.service.acaocorretiva;

import org.example.model.AcaoCorretiva;
import org.example.model.Equipamento;
import org.example.model.Falha;
import org.example.repository.acaoCorretiva.AcaoCorretivaRepository;
import org.example.repository.acaoCorretiva.AcaoCorretivaRepositoryImpl;
import org.example.repository.equipamento.EquipamentoRepository;
import org.example.repository.equipamento.EquipamentoRepositoryImpl;
import org.example.repository.falha.FalhaRepository;
import org.example.repository.falha.FalhaRepositoryImpl;

import java.sql.SQLException;

public class AcaoCorretivaServiceImpl implements AcaoCorretivaService{

    private AcaoCorretivaRepository acaoCorretivaRepository = new AcaoCorretivaRepositoryImpl();
    private FalhaRepository falhaRepository = new FalhaRepositoryImpl();
    private EquipamentoRepository equipamentoRepository = new EquipamentoRepositoryImpl();

    @Override
    public AcaoCorretiva registrarConclusaoDeAcao(AcaoCorretiva acao) throws SQLException {
        if (acao.getFalhaId() == falhaRepository.buscarFalhaPorId(acao.getFalhaId()).getId()) {
            falhaRepository.atualizarStatusFalha(acao.getFalhaId(), "RESOLVIDA");

            Falha falha = falhaRepository.buscarFalhaPorId(acao.getFalhaId());
            if (falha.getId() == equipamentoRepository.buscarEquipamentoPorId(falha.getId()).getId()) {
                Equipamento equipamento = equipamentoRepository.buscarEquipamentoPorId(falha.getId());

                equipamentoRepository.atualizarStatusEquipamento(equipamento.getId(), "OPERACIONAL");
            }

            return acaoCorretivaRepository.registrarConclusaoDeAcao(acao);
        } else {
            throw new RuntimeException("Falha não encontrada!");
        }
    }
}
