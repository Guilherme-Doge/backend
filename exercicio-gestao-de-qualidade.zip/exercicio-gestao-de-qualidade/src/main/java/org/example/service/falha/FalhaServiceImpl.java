package org.example.service.falha;

import org.example.model.Falha;
import org.example.repository.falha.FalhaRepository;
import org.example.repository.falha.FalhaRepositoryImpl;
import org.example.service.equipamento.EquipamentoService;
import org.example.service.equipamento.EquipamentoServiceImpl;

import java.sql.SQLException;
import java.util.List;

public class FalhaServiceImpl implements FalhaService{

    EquipamentoService equipamentoService = new EquipamentoServiceImpl();
    FalhaRepository falhaRepository = new FalhaRepositoryImpl();

    @Override
    public Falha registrarNovaFalha(Falha falha) throws SQLException {
        if (equipamentoService.buscarEquipamentoPorId(falha.getEquipamentoId()).getId() != falha.getEquipamentoId()) {
            throw new IllegalArgumentException("IllegalArgumentException: Equipamento não encontrado!");
        }
        falha.setStatus("ABERTA");
        falha = falhaRepository.registrarNovaFalha(falha);
        if (falha.getCriticidade().equals("CRITICA")) {
            equipamentoService.atualizarStatusEquipamento(falha.getId(), "EM_MANUTENCAO");
        }
        return falha;
    }

    @Override
    public List<Falha> buscarFalhasCriticasAbertas() throws SQLException {
        return falhaRepository.buscarFalhasCriticasAbertas();
    }
}
