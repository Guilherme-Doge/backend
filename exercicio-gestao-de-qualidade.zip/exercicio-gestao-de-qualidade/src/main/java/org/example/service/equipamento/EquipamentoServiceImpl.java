package org.example.service.equipamento;

import org.example.model.Equipamento;
import org.example.repository.equipamento.EquipamentoRepositoryImpl;

import java.sql.SQLException;

public class EquipamentoServiceImpl implements EquipamentoService{

    private EquipamentoRepositoryImpl equipamentRepositoryImpl = new EquipamentoRepositoryImpl();

    @Override
    public Equipamento criarEquipamento(Equipamento equipamento) throws SQLException {
        equipamentRepositoryImpl.salvarEquipamento(equipamento);
        return equipamento;
    }

    @Override
    public Equipamento buscarEquipamentoPorId(Long id) throws SQLException {
        Equipamento equipamento = equipamentRepositoryImpl.buscarEquipamentoPorId(id);
        return equipamento;
    }
    
    @Override
    public Equipamento atualizarStatusEquipamento(Long id, String status) throws SQLException {
        Equipamento equipamento = equipamentRepositoryImpl.atualizarStatusEquipamento(id, status);
        return equipamento;
    }
}
