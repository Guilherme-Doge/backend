package org.example.repository;

import java.sql.SQLException;

public class AcaoCorretivaImpl implements AcaoCorretiva {
    public AcaoCorretiva registrarConclusaoDeAcao(int id, String status) throws SQLException {
        return null;
    }
}
