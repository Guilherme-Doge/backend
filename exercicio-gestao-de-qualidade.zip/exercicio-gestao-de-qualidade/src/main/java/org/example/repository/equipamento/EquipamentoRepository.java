package org.example.repository.equipamento;

import java.sql.SQLException;

import org.example.model.Equipamento;

public interface EquipamentoRepository {
    Equipamento salvarEquipamento(Equipamento equipamento) throws SQLException;

    Equipamento buscarEquipamentoPorId(Long id) throws SQLException;

    Equipamento atualizarStatusEquipamento(Long id, String status) throws SQLException;
}