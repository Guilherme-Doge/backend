package org.example.repository.equipamento;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.example.database.Conexao;
import org.example.model.Equipamento;

public class EquipamentoRepositoryImpl implements EquipamentoRepository {

    @Override
    public Equipamento salvarEquipamento(Equipamento equipamento) throws SQLException {
        String command = """
                    INSERT INTO equipamento (
                        nome, 
                        numero_de_serie, 
                        area_setor, 
                        status_operacional
                    ) VALUES (?, ?, ?, ?)
                    """;
        try (Connection conn = Conexao.conectar();
            PreparedStatement stmt = conn.prepareStatement(command, PreparedStatement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, equipamento.getNome());
            stmt.setString(2, equipamento.getNumeroDeSerie());
            stmt.setString(3, equipamento.getAreaSetor());
            stmt.setString(4, "OPERACIONAL");

            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    equipamento.setId(rs.getLong(1));
                    return equipamento;
                } else {
                    throw new SQLException("Equipamento não cadastrado");
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return equipamento;
    }

    @Override
    public Equipamento buscarEquipamentoPorId(Long id) throws SQLException {
        String command = """
                        SELECT
                            id,
                            nome,
                            numero_de_serie,
                            area_setor,
                            status_operacional
                        FROM equipamento
                        WHERE id = ?;
                        """;

        try (Connection conn = Conexao.conectar();
            PreparedStatement stmt = conn.prepareStatement(command)) {
            
            stmt.setLong(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Equipamento(
                        rs.getLong("id"),
                        rs.getString("nome"),
                        rs.getString("numero_de_serie"),
                        rs.getString("area_setor"),
                        rs.getString("status_operacional")
                    );
                }
            }
        }
        throw new IllegalArgumentException("Equipamento não encontrado!");
    }

    @Override
    public Equipamento atualizarStatusEquipamento(Long id, String status) throws SQLException {
        String command = """
                        UPDATE equipamento
                        SET status_operacional = ?
                        WHERE id = ?;
                        """;
        try (Connection conn = Conexao.conectar();
            PreparedStatement stmt = conn.prepareStatement(command)) {
            
            stmt.setString(1, status);
            stmt.setLong(2, id);
            stmt.executeUpdate();

            Equipamento equipamento = buscarEquipamentoPorId(id);
            return equipamento;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        throw new RuntimeException();
    }
}
