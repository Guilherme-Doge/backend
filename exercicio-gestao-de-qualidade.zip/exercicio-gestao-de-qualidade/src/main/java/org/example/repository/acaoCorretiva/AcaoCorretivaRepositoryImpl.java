package org.example.repository.acaoCorretiva;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.example.database.Conexao;
import org.example.model.AcaoCorretiva;

public class AcaoCorretivaRepositoryImpl implements AcaoCorretivaRepository {
    
    public AcaoCorretiva registrarConclusaoDeAcao(AcaoCorretiva acao) throws SQLException {
        String command = """
                        INSERT INTO acao_corretiva(
                            falha_id, 
                            data_hora_inicio,
                            data_hora_fim,
                            responsavel,
                            descricao_acao)
                        VALUES (?,?,?,?,?)
                        """;
        try (Connection conn = Conexao.conectar();
            PreparedStatement stmt = conn.prepareStatement(command, PreparedStatement.RETURN_GENERATED_KEYS)) {
            
            stmt.setLong(1, acao.getFalhaId());
            stmt.setTimestamp(2, Timestamp.valueOf(acao.getDataHoraInicio()));
            stmt.setTimestamp(3, Timestamp.valueOf(acao.getDataHoraFim()));
            stmt.setString(4, acao.getResponsavel());
            stmt.setString(5, acao.getDescricaoArea());

            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    acao.setId(rs.getLong(1));
                    return acao;
                }
            } 
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        throw new RuntimeException("Falha não encontrada!");
    }
}
