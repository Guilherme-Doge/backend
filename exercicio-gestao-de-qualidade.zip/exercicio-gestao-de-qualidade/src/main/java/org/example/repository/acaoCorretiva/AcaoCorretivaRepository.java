package org.example.repository.acaoCorretiva;

import java.sql.SQLException;

import org.example.model.AcaoCorretiva;

public interface AcaoCorretivaRepository {
    AcaoCorretiva registrarConclusaoDeAcao(AcaoCorretiva acao) throws SQLException;
}
