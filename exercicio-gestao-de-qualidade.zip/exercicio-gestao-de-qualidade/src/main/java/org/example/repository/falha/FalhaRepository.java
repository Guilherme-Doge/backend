package org.example.repository.falha;

import java.sql.SQLException;
import java.util.List;

import org.example.model.Falha;

public interface FalhaRepository {
    Falha registrarNovaFalha(Falha falha) throws SQLException;

    List<Falha> buscarFalhasCriticasAbertas() throws SQLException;

    Falha buscarFalhaPorId(Long id) throws SQLException;

    Falha atualizarStatusFalha(Long id, String status) throws SQLException;
}
