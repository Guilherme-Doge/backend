package org.example.repository;

import java.sql.SQLException;

public interface AcaoCorretiva {
    AcaoCorretiva registrarConclusaoDeAcao(int id, String status) throws SQLException;
}
