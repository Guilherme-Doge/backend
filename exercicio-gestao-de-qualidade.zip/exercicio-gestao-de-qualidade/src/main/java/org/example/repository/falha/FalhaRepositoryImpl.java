package org.example.repository.falha;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;


import org.example.database.Conexao;
import org.example.model.Falha;

public class FalhaRepositoryImpl implements FalhaRepository {

    @Override
    public Falha registrarNovaFalha(Falha falha) throws SQLException {
        String command = """
                        INSERT INTO falha(   
                            equipamento_id,
                            data_hora_ocorrencia,
                            descricao,
                            criticidade,
                            status,
                            tempo_parada_horas)
                        VALUES (?,?,?,?,?,?)
                        """;
        try (Connection conn = Conexao.conectar();
            PreparedStatement stmt = conn.prepareStatement(command, PreparedStatement.RETURN_GENERATED_KEYS)) {

            Timestamp dataHoraOcorrencia = Timestamp.valueOf(falha.getDataHoraOcorrencia());

            stmt.setLong(1, falha.getEquipamentoId());
            stmt.setTimestamp(2, dataHoraOcorrencia);
            stmt.setString(3, falha.getDescricao());
            stmt.setString(4, falha.getCriticidade());
            stmt.setString(5, falha.getStatus());
            stmt.setBigDecimal(6, falha.getTempoParadaHoras());

            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    falha.setId(rs.getLong(1));
                    return falha;
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        throw new RuntimeException("Falha não cadastrada");
    }

    @Override
    public List<Falha> buscarFalhasCriticasAbertas() throws SQLException {
        List<Falha> falhasCriticasAbertas = new ArrayList<>();
        String command = """
                        SELECT id,
                            equipamento_id,
                            data_hora_ocorrencia,
                            descricao,
                            criticidade,
                            status,
                            tempo_parada_horas
                        FROM falha
                        WHERE criticidade = 'CRITICA' AND status = 'ABERTA';
                        """;
        try (Connection conn = Conexao.conectar();
            PreparedStatement stmt = conn.prepareStatement(command)) {

                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        falhasCriticasAbertas.add(new Falha(
                            rs.getLong("id"),
                            rs.getLong("equipamento_id"),
                            rs.getTimestamp("data_hora_ocorrencia").toLocalDateTime(),
                            rs.getString("descricao"),
                            rs.getString("criticidade"),
                            rs.getString("status"),
                            rs.getBigDecimal("tempo_parada_horas")
                        ));
                    }
                }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return falhasCriticasAbertas;
    }
    
    @Override
    public Falha buscarFalhaPorId(Long id) throws SQLException {
        String command = """
                SELECT id,
                    equipamento_id,
                    data_hora_ocorrencia,
                    descricao,
                    criticidade,
                    status,
                    tempo_parada_horas
                FROM falha
                WHERE id = ?;
                """;

        try (Connection conn = Conexao.conectar();
            PreparedStatement stmt = conn.prepareStatement(command)) {

            stmt.setLong(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Falha(
                            rs.getLong("id"),
                            rs.getLong("equipamento_id"),
                            rs.getTimestamp("data_hora_ocorrencia").toLocalDateTime(),
                            rs.getString("descricao"),
                            rs.getString("criticidade"),
                            rs.getString("status"),
                            rs.getBigDecimal("tempo_parada_horas")
                    );
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException();
        }
        throw new RuntimeException();
    }

    @Override
    public Falha atualizarStatusFalha(Long id, String status) throws SQLException {
        String command = """
                        UPDATE Falha
                        SET status = ?
                        WHERE id = ?;
                        """;
        try (Connection conn = Conexao.conectar();
            PreparedStatement stmt = conn.prepareStatement(command)) {

            stmt.setString(1, status);
            stmt.setLong(2, id);
            stmt.executeUpdate();
            return buscarFalhaPorId(id);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        throw new RuntimeException();
    }
}