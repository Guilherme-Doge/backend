package org.example.repository;

import org.example.model.Produto;
import org.example.util.ConexaoBanco;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProdutoRepositoryImpl implements ProdutoRepository{

    @Override
    public Produto save(Produto produto) throws SQLException {
        String command = """
                INSERT INTO produtos (nome, preco, quantidade, categoria) 
                VALUES (?, ?, ?, ?);
                """;

        try (Connection conn = ConexaoBanco.conectar();
            PreparedStatement stmt = conn.prepareStatement(command, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, produto.getNome());
            stmt.setDouble(2, produto.getPreco());
            stmt.setInt(3, produto.getQuantidade());
            stmt.setString(4, produto.getCategoria());
            
            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    produto.setId(rs.getInt(1));
                } else {
                    throw new SQLException("Falha ao inserir produto: nenhum ID gerado.");
                }
            }
            return produto;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            throw e; 
        }
    }

    @Override
    public List<Produto> findAll() throws SQLException {
        List<Produto> produtos = new ArrayList<>();

        String command = """
                SELECT
                    id,
                    nome,
                    preco,
                    quantidade,
                    categoria
                FROM produtos;
                """;
        try (Connection conn = ConexaoBanco.conectar();
            PreparedStatement stmt = conn.prepareStatement(command)) {
            
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                produtos.add(new Produto(rs.getInt("id"), 
                                        rs.getString("nome"), 
                                        rs.getDouble("preco"), 
                                        rs.getInt("quantidade"), 
                                        rs.getString("categoria")));
            }
            return produtos;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        throw new SQLException();
    }

    @Override
    public Produto findById(int id) throws SQLException {
        String command = """
                SELECT
                    id,
                    nome,
                    preco,
                    quantidade,
                    categoria
                FROM produtos
                WHERE id = ?;
                """;
        try (Connection conn = ConexaoBanco.conectar();
            PreparedStatement stmt = conn.prepareStatement(command, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, id);
            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                Produto produto = new Produto();
                produto.setId(rs.getInt(1));
                return produto;
            } 
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    @Override
    public Produto update(Produto produto) throws SQLException {
        String command = """
                UPDATE produtos
                SET nome = ?,
                    preco = ?,
                    quantidade = ?,
                    categoria = ?
                WHERE id = ?;
                """;
        try (Connection conn = ConexaoBanco.conectar();
            PreparedStatement stmt = conn.prepareStatement(command)) {
            
            stmt.setString(1, produto.getNome());
            stmt.setDouble(2, produto.getPreco());
            stmt.setInt(3, produto.getQuantidade());
            stmt.setString(4, produto.getNome());
            stmt.setInt(5, produto.getId());
            stmt.executeUpdate();

            return produto;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        throw new SQLException();
    }

    @Override
    public void deleteById(int id) throws SQLException {
        String command = "DELETE FROM produtos WHERE id = ?";
        try (Connection conn = ConexaoBanco.conectar();
            PreparedStatement stmt = conn.prepareStatement(command)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}
